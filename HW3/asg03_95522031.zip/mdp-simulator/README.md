A simulator for running MDP algorithms graphically.

Used for designing MDP related questions for IUST-AI982 class.
* Solutions will be uploaded 8 days after deadline.

https://iust-courses.github.io/ai982/

## How to run
Small map:
```bash
python main.py type=smallWorld
```
Large map:
```bash
python main.py type=largeWorld

```